package controller;

public final class ControllerConst {

	static final String USER_MENU = "usermenu";
	static final String USER_TASKS = "items";
	static final String ERROR = "error";
	static final String LOG_OUT = "login";
	static final String LOG_IN = "login";
	static final String ADD_TASK = "addtask";
	static final String WELCOME = "welcome";
	static final String DELETE_TASK = "deletetask";
	static final String EDIT_TASK = "edittask";
	static final String SIGN_IN = "signin";
	static final String ABOUT = "about";


	
	
	
	

}
