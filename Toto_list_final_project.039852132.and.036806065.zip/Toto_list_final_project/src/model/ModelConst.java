package model;

/**
 * App vars definition
 * @author moshe
 *
 */

public final class ModelConst {

	
	static final String OPEN = "open";
	static final String CLOSE = "close";

	
}
